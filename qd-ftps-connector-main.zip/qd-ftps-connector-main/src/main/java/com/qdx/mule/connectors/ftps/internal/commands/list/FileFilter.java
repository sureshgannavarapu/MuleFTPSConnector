package com.qdx.mule.connectors.ftps.internal.commands.list;

public enum FileFilter {
    FILE,
    DIRECTORY,
    ANY
}
