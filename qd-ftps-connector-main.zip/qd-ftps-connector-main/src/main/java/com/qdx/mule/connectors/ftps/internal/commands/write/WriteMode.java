package com.qdx.mule.connectors.ftps.internal.commands.write;

public enum WriteMode {
    APPEND,
    OVERWRITE,
    NEW
}
